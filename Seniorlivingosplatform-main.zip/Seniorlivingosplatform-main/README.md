
  # Senior Living OS Platform

  This is a code bundle for Senior Living OS Platform. The original project is available at https://www.figma.com/design/FoEM9BehkTDoz0ui3s7dTE/Senior-Living-OS-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  